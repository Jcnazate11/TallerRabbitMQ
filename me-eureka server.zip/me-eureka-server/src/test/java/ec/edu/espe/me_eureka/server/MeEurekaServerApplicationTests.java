package ec.edu.espe.me_eureka.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
